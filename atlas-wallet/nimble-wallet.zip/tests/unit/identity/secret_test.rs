#[cfg(test)]
mod tests {
    use ed25519_dalek::SecretKey;
    use rand::{rngs::OsRng, RngCore};
    use nimble_wallet::identity::errors::IdentityError;
    use nimble_wallet::identity::secret::{encrypt_secret_key, decrypt_secret_key};
    use nimble_wallet::utils::security::generate_salt;

    /// Testa se uma chave secreta pode ser criptografada e depois corretamente descriptografada com a mesma senha.
    #[test]
    fn test_encrypt_and_decrypt_secret_key() -> Result<(), IdentityError> {
        let salt = generate_salt();
        let mut sk_bytes = [0u8; 32];
        OsRng.fill_bytes(&mut sk_bytes);
        let sk = SecretKey::from_bytes(&sk_bytes).unwrap();

        let password = "my-secure-password".to_string();
        let encrypted = encrypt_secret_key(&sk, password.clone(), salt)?;

        let decrypted = decrypt_secret_key(&encrypted, password, salt)?;

        assert_eq!(sk.to_bytes(), decrypted.to_bytes());

        Ok(())
    }

    /// Testa se descriptografar com a senha errada falha.
    #[test]
    fn test_decrypt_with_wrong_password_fails() {
        let salt = generate_salt();
        let mut sk_bytes = [0u8; 32];
        OsRng.fill_bytes(&mut sk_bytes);
        let sk = SecretKey::from_bytes(&sk_bytes).unwrap();

        let encrypted = encrypt_secret_key(&sk, "correct-password".to_string(), salt).unwrap();

        let result = decrypt_secret_key(&encrypted, "wrong-password".to_string(), salt);

        assert!(result.is_err());
    }

    /// Testa se descriptografar dados corrompidos falha.
    #[test]
    fn test_decrypt_invalid_data_fails() {
        let salt = generate_salt();
        let invalid_data = "invalid_base58_string!";

        let result = decrypt_secret_key(invalid_data, "any-password".to_string(), salt);

        assert!(result.is_err());
    }
}
