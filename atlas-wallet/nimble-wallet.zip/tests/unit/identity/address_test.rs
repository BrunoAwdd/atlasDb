#[cfg(test)]
mod tests {
    use nimble_wallet::identity::address::Address;
    use nimble_wallet::identity::errors::IdentityError;
    use nimble_wallet::identity::identity::{generate, seed};

    /// Asserts that an address generated from a public key
    /// can be parsed back to the same public key.
    #[test]
    fn test_address_from_public_key_and_back() -> Result<(), IdentityError> {
        // Usa seu próprio sistema de seed para gerar uma identidade
        let seed = seed();
        let password = "123456".to_string();
        let identity_bundle = generate(&seed, password)?;
 
        // Pegamos a public key de um profile (exemplo: exposed)
        let public_key = identity_bundle.pub_exposed;

        // Gera o endereço
        let address_str = Address::address_from_pk(&public_key)
            .map_err(|_| IdentityError::InvalidPublicKey("Failed to generate address".to_string()))?;

        // Extrai a public key de volta a partir do address
        let extracted_pk = Address::public_key_from_str(&address_str)?;

        assert_eq!(public_key, extracted_pk);

        Ok(())
    }



    /// Verifies that an invalid address string is rejected.
    #[test]
    fn test_invalid_address_is_rejected() {
        let invalid_address = "nimble1invalidaddress";

        assert!(!Address::is_valid(invalid_address));
        assert!(Address::public_key_from_str(invalid_address).is_err());
    }

    /// Verifies that a random string that is not bech32 fails.
    #[test]
    fn test_completely_invalid_format_fails() {
        let random_string = "not_even_bech32_encoded";
        assert!(Address::try_from(random_string).is_err());
    }
}
