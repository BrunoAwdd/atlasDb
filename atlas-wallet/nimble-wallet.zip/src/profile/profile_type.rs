use ed25519_dalek::{
    Keypair, 
    PublicKey,  
    Signature, 
    Signer, 
    Verifier
};
use nimble_sdk::{address::address::{Address, TypedAddress}, address::profile_address::ProfileAddress, transactions::{errors::TransactionError, payload::TransferPayload, TransferRequest}};
use serde::{Serialize, Deserialize};
use crate::{errors::NimbleError, identity::{errors::IdentityError, secret::decrypt_secret_key}};
use crate::profile::{hidden::HiddenProfile, exposed::ExposedProfile};

pub enum Profile {
    Hidden(HiddenProfile),
    Exposed(ExposedProfile),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProfileData {
    #[serde(with = "crate::identity::serde_pubkey")]
    pub public_key: ed25519_dalek::PublicKey,

    //#[serde(skip_serializing, skip_deserializing)]
    #[serde(default)] 
    encrypted_sk: Option<String>,

    pub id: String,
    pub address: TypedAddress,
    pub permissions: Vec<String>,
    pub transactions: Vec<String>,
    pub salt: [u8; 16],
    pub is_public: bool,
}

impl ProfileData {
    pub fn new(
        id: String,
        public_key: ed25519_dalek::PublicKey,
        encrypted_sk: Option<String>,
        address: TypedAddress,
        permissions: Vec<String>,
        salt: [u8; 16],
        is_public: bool,
    ) -> Self {
        Self {
            id,
            public_key,
            encrypted_sk,
            address,
            permissions,
            transactions: vec![],
            salt,
            is_public,
        }
    }

    pub fn add_payload(&mut self, to: &Address, amount: u64) {
        let payload = TransferPayload::new(&self.address.as_str(), to, amount);
        self.transactions.push(payload.to_string());
    }

    pub fn build_signed_request<'a>(
        &'a self,
        to: &'a Address,
        amount: u64,
        password: String,
        memo: Option<&str>,
    ) -> Result<TransferRequest<'a>, NimbleError> {
        let payload = TransferPayload::new(&self.address.as_str(), to, amount);
        let sig2 = self.sign(password, payload.to_string().as_bytes())?;

        let request = TransferRequest::build_signed_request(
            &self.address.as_str(),
            &to,
            amount,
            sig2.to_vec(),
            memo.map(|m| m.to_string()),
        )?;

        Ok(request)
    }

    pub fn sign(&self, encryption_key: String, message: &[u8]) -> Result<[u8; 64], IdentityError> {
        println!("🔐 Signing message Profile Type {:?}", self);
        let encrypted = self.encrypted_sk.clone().ok_or(IdentityError::InvalidPrivateKey("missing key".into()))?;
        println!("🔐 Decrypting key {:?}", encrypted);
        let secret = decrypt_secret_key(&encrypted, encryption_key, self.salt)?;
        let public = PublicKey::from(&secret);
        let keypair = Keypair { secret, public };
        Ok(keypair.sign(message).to_bytes())
    }

    pub fn validate_transfer(&self, request: TransferRequest) -> Result<(), NimbleError> {
        let payload = request.to_payload();

        if !payload.is_valid() {
            return Err(TransactionError::InvalidPayload("Invalid payload".into()).into());
        }

        let signature = Signature::from_bytes(&request.sig2)
            .map_err(|_| TransactionError::InvalidPasswordSignature("Invalid signature format".into()))?;

        self.public_key
            .verify(payload.to_string().as_bytes(), &signature)
            .map_err(|_| TransactionError::InvalidPasswordSignature("Signature verification failed".into()))?;

        Ok(())
    }

    pub fn validate_transferbkp(&self, password: String, request: TransferRequest) -> Result<(), NimbleError> {
        let payload = request.to_payload();
        let expected_sig2 = self.sign(password, payload.to_string().as_bytes())?;

        if !payload.is_valid() {
            println!("Invalid Payload");
            return Err(TransactionError::InvalidPayload("Invalid payload".into()).into());  
        }

        if request.sig2 != expected_sig2 {
            println!("Invalid Signature");
            return Err(TransactionError::InvalidPasswordSignature("Invalid signature".into()).into());
        }

        Ok(())
    }


    pub fn validate_permissions(&self, permission: String) -> Result<(), IdentityError> {
        if !self.permissions.contains(&permission) {
            return Err(IdentityError::InvalidPermission(
                format!("Profile '{}' does not have permission '{}'", self.id, permission)
            ));
        }
        Ok(())
    }

    pub fn try_validate_permissions(&self, permission: &str) -> bool {
        self.permissions.contains(&permission.to_string())
    }

    pub fn zeroize(&mut self) {
        use zeroize::Zeroize;
        self.encrypted_sk.zeroize();
        self.salt.zeroize();
    }

     pub fn is_cleared(&self) -> bool {
        match &self.encrypted_sk {
            Some(sk) => sk.is_empty(),
            None => true,
        }
    }

    pub fn is_public(&self) -> bool {
        self.is_public
    }

}

pub trait ProfileType {
    fn new_from_seed(
        seed: &[u8],
        password: String, 
        label: &str, 
        permissions: Vec<String>
    ) -> Result<Self, IdentityError> where Self: Sized;

    fn add_payload(&mut self, to: &Address, amount: u64);

    fn build_signed_request<'a>(
        &'a self,
        to: &'a Address,
        amount: u64,
        password: String,
        memo: Option<&str>,
    ) -> Result<TransferRequest<'a>, NimbleError>;

    fn sign(&self, encryption_key: String, message: &[u8]) -> Result<[u8; 64], IdentityError>;

    fn validate_transfer(&self, request: TransferRequest) -> Result<(), NimbleError>;

    fn validate_permissions(&self, permission: String) -> Result<(), IdentityError>;

    fn try_validate_permissions(&self, permission: &str) -> bool;

    fn zeroize(&mut self);

    fn is_cleared(&self) -> bool;

    fn is_public(&self) -> bool;
}

impl Profile {
    pub fn address(&self) -> &TypedAddress {
        match self {
            Profile::Hidden(p) => p.address(),
            Profile::Exposed(p) => p.address(),
        }
    }

    pub fn id(&self) -> &str {
        match self {
            Profile::Hidden(p) => p.id(),
            Profile::Exposed(p) => p.id(),
        }
    }
}

impl ProfileType for Profile {
    fn new_from_seed(
        _seed: &[u8],
        _password: String,
        _label: &str,
        _permissions: Vec<String>,
    ) -> Result<Self, IdentityError> {
        unimplemented!("Use HiddenProfile or ExposedProfile directly for creation")
    }

    fn add_payload(&mut self, to: &Address, amount: u64) {
        match self {
            Profile::Hidden(p) => p.add_payload(to, amount),
            Profile::Exposed(p) => p.add_payload(to, amount),
        }
    }

    fn build_signed_request<'a>(
        &'a self,
        to: &'a Address,
        amount: u64,
        password: String,
        memo: Option<&str>,
    ) -> Result<TransferRequest<'a>, NimbleError> {
        match self {
            Profile::Hidden(p) => p.build_signed_request(to, amount, password, memo),
            Profile::Exposed(p) => p.build_signed_request(to, amount, password, memo),
        }
    }

    fn sign(&self, encryption_key: String, message: &[u8]) -> Result<[u8; 64], IdentityError> {
        match self {
            Profile::Hidden(p) => p.sign(encryption_key, message),
            Profile::Exposed(p) => p.sign(encryption_key, message),
        }
    }

    fn validate_transfer(&self, request: TransferRequest) -> Result<(), NimbleError> {
        match self {
            Profile::Hidden(p) => p.validate_transfer(request),
            Profile::Exposed(p) => p.validate_transfer(request),
        }
    }

    fn validate_permissions(&self, permission: String) -> Result<(), IdentityError> {
        match self {
            Profile::Hidden(p) => p.validate_permissions(permission),
            Profile::Exposed(p) => p.validate_permissions(permission),
        }
    }

    fn try_validate_permissions(&self, permission: &str) -> bool {
        match self {
            Profile::Hidden(p) => p.try_validate_permissions(permission),
            Profile::Exposed(p) => p.try_validate_permissions(permission),
        }
    }

    fn zeroize(&mut self) {
        match self {
            Profile::Hidden(p) => p.zeroize(),
            Profile::Exposed(p) => p.zeroize(),
        }
    }

    fn is_cleared(&self) -> bool {
        match self {
            Profile::Hidden(p) => p.is_cleared(),
            Profile::Exposed(p) => p.is_cleared(),
        }
    }

    fn is_public(&self) -> bool {
        match self {
            Profile::Hidden(p) => p.is_public(),
            Profile::Exposed(p) => p.is_public(),
        }
    }
}