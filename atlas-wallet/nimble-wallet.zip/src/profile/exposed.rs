

use ed25519_dalek::{SecretKey, PublicKey};
use nimble_sdk::address::address::TypedAddress;
use nimble_sdk::address::exposed_address::ExposedAddress;
use serde::{Serialize, Deserialize};
use crate::{errors::NimbleError, identity::errors::IdentityError};
use crate::identity::secret::encrypt_secret_key;

use nimble_sdk::{
    address::address::Address, transactions::TransferRequest, utils::security::generate_salt
};

use super::profile_type::{ProfileData, ProfileType};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExposedProfile {
    pub data: ProfileData,
}

impl ExposedProfile {
    pub fn address(&self) -> &TypedAddress {
        &self.data.address
    }

    pub fn id(&self) -> &str {
        &self.data.id
    }
}


impl ProfileType for ExposedProfile  {
     fn new_from_seed(
        seed: &[u8],
        password: String,
        label: &str,
        permissions: Vec<String>,
    ) -> Result<Self, IdentityError> {
        let secret = SecretKey::from_bytes(seed)
            .map_err(IdentityError::ProfileCreationFailed)?;
        let public = PublicKey::from(&secret);

        let address = TypedAddress::Exposed(ExposedAddress::from_public_key(&public)?);

        let salt = generate_salt();
        let encrypted = encrypt_secret_key(&secret, password, salt)?;

        println!("🔐 Encrypted key {:?}", encrypted);

        Ok(ExposedProfile {
            data: ProfileData::new(
                label.to_string(),
                public,
                Some(encrypted),
                address,
                permissions,
                salt,
                true,
            ),
        })
    }

    fn add_payload(&mut self, to: &Address, amount: u64) {
        self.data.add_payload(to, amount);
    }

    fn build_signed_request<'a>(
        &'a self,
        to: &'a Address,
        amount: u64,
        password: String,
        memo: Option<&str>,
    ) -> Result<TransferRequest<'a>, NimbleError> {
        self.data.build_signed_request(to, amount, password, memo)
    }

    fn sign(&self, encryption_key: String, message: &[u8]) -> Result<[u8; 64], IdentityError> {
        println!("🔐 Signing message {:?}", self.data.id);
        self.data.sign(encryption_key, message)
    }

    fn validate_transfer(&self, request: TransferRequest) -> Result<(), NimbleError> {
        self.data.validate_transfer(request)
    }

    fn validate_permissions(&self, permission: String) -> Result<(), IdentityError> {
        self.data.validate_permissions(permission)
    }

    fn try_validate_permissions(&self, permission: &str) -> bool {
        self.data.try_validate_permissions(permission)
    }

    fn zeroize(&mut self) {
        self.data.zeroize();
    }

    fn is_cleared(&self) -> bool {
        self.data.is_cleared()
    }

    fn is_public(&self) -> bool {
        self.data.is_public
    }
}

