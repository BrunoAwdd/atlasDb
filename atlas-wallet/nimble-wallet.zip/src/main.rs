
pub mod identity;
pub mod session;
pub mod profile;
pub mod vault;
pub mod errors;

use errors::NimbleError;
use identity::identity::generate;
use nimble_sdk::{address::profile_address::ProfileAddress, utils::security::generate_seed};
use vault::vault::VaultData;
use profile::profile_type::ProfileType;

fn main() -> Result<(), NimbleError> {
    println!("🔐 Mel Blockchain");
    //test_permissions()?;
    create_vault();
    //sing();
    Ok(())
}

fn sing() -> Result<(), NimbleError> {
    let password = "test_password".to_string();
    let vault = VaultData::new(1, vec![0u8; 12]);
    let session = vault.load_session(password.clone(), "test_vault_data.bin")?;

    println!("🔐 Session");

    let exposed_address = session.identity.exposed.address().as_str();

    println!("🔐 Exposed Address: {:?}", exposed_address);

    let signed_message = session.create_signed_transfer(&exposed_address, 100, password, None)?;

    println!("🔐 Signed Message: {:?}", signed_message);

    session.profile.validate_transfer(signed_message)?;

    Ok(())
}


fn test_permissions() -> Result<(), NimbleError> {
    let password = "123456".to_string();
    let vault = VaultData::new(1, vec![0u8; 12]);

    println!("🔐 Vault: {:?}", vault);

    let bundle = vault.load_identity_bundle(password, "ali")?;

    println!("🔐 Bundle: {:?}", bundle);

    let hidden = bundle.identity.hidden;
    let exposed = bundle.identity.exposed;

    println!("🔐 SK Master       : {:?}", bundle.sk_master);
    println!("🔐 SK Exposed      : {:?}", hidden.address());
    println!("🔐 Hidden Transfer     : {:?}", hidden.try_validate_permissions("transfer"));
    println!("🔐 Exposed Transfer     : {:?}", exposed.try_validate_permissions("transfer"));

    Ok(())
}

fn create_vault() -> Result<(), NimbleError> {
    let password = "test_password".to_string();
    let path = "test_vault_data.bin";

    let seed = generate_seed();    
    let bundle = generate(&seed, "test_password".into()).unwrap();
    let vault = VaultData::new(1, vec![0u8; 12]);

    println!("🔐 Bundle: {:?}", bundle);

    // Salvar o bundle
    vault.save_identity_bundle(&bundle, password.clone(), path).expect("Failed to save bundle");
    
    Ok(())
}
