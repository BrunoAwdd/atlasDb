use aes_gcm::{
    Aes256Gcm, 
    aead::{Aead, KeyInit, OsRng, generic_array::GenericArray, rand_core::RngCore}
};
use argon2::{password_hash::{Salt, SaltString}, Argon2, PasswordHasher};
use ed25519_dalek::SecretKey;
use sha2::{Sha256, Digest};

use base64::{engine::general_purpose, Engine as _};


use crate::vault::password::Password;

use super::errors::IdentityError;


/// Derives a 32-byte secret from a password and a contextual string using Argon2 and SHA-256.
///
/// This function securely combines a password with a `context` string to generate a
/// deterministic 32-byte secret. It first concatenates the password and context,
/// uses SHA-256 to hash the context into a salt, and then applies the Argon2 algorithm
/// for key derivation. The result is hashed again with SHA-256 to produce a fixed-size key.
///
/// This can be used to generate symmetric keys or secrets that are:
/// - Deterministic (same input yields same output),
/// - Domain-separated via the context string,
/// - Uniformly 32 bytes in length.
///
/// # Arguments
///
/// * `password` - The plaintext password or passphrase.
/// * `context` - A domain/context string used to derive a unique secret from the same password
///               (e.g. `"auth"`, `"encryption"`, `"backup-key"`).
///
/// # Errors
///
/// Returns a [`PasswordError`] if:
/// - The salt encoding fails (likely if context is malformed or too short),
/// - The Argon2 password hashing fails internally,
/// - The resulting hash from Argon2 is unexpectedly missing.
///
/// # Returns
///
/// A 32-byte array (`[u8; 32]`) representing the derived secret.
///
/// # Example
///
/// ```rust
/// let password = "hunter2";
/// let context = "login";
/// let secret = derive_password_secret(password, context).unwrap();
/// assert_eq!(secret.len(), 32);
/// ```
pub fn derive_password_secret(password: Password, context: &str) -> Result<[u8; 32], IdentityError> {
    let mut combined = password.password.clone();
    combined.extend_from_slice(context.as_bytes());

    // Gerar hash do contexto
    let mut hasher = Sha256::new();
    hasher.update(context.as_bytes());
    let hash = hasher.finalize();

    // Codificar o hash como Base64
    let salt_b64_string = general_purpose::STANDARD_NO_PAD.encode(&hash[..16]);

    let salt = SaltString::from_b64(&salt_b64_string)
        .map_err(|e| IdentityError::EncryptionFailed(e.to_string()))?;

        let hasher = Argon2::default();
    let result = hasher.hash_password(combined.as_slice(), &salt)?;

    let parsed_hash = result.hash.ok_or(IdentityError::MissingHash)?;
    let hash_bytes = Sha256::digest(parsed_hash.as_bytes());

    let mut secret = [0u8; 32];
    secret.copy_from_slice(&hash_bytes[..32]);

    Ok(secret)
}

pub fn encrypt_secret_key(sk: &SecretKey, password: Password) -> Result<String, IdentityError> {
    let key = derive_password_secret(password, "profile:sk")?;
    let encrypted = encrypt_data(&sk.to_bytes(), &key)?;
    Ok(bs58::encode(encrypted).into_string())
}

pub fn decrypt_secret_key(encoded: &str, password: Password) -> Result<SecretKey, IdentityError> {
    let key = derive_password_secret(password, "profile:sk")?;
    let decoded = bs58::decode(&encoded).into_vec()?;
    let decrypted = decrypt_data(&decoded, &key)?;
    let secret_key = SecretKey::from_bytes(&decrypted).map_err(|e|IdentityError::InvalidSecretKey(e))?;
    Ok(secret_key)
}

fn encrypt_data(data: &[u8], key: &[u8; 32]) -> Result<Vec<u8>, IdentityError> {
    let cipher = Aes256Gcm::new(GenericArray::from_slice(key));
    let mut nonce = [0u8; 12];
    OsRng.fill_bytes(&mut nonce);
    let ciphertext = cipher.encrypt(GenericArray::from_slice(&nonce), data)
        .map_err(|e | IdentityError::EncryptionFailed(e.to_string()))?;
    let mut output = nonce.to_vec();
    output.extend_from_slice(&ciphertext);
    Ok(output)
}

fn decrypt_data(encrypted: &[u8], key: &[u8; 32]) -> Result<Vec<u8>, IdentityError> {
    if encrypted.len() < 12 {
        return Err(IdentityError::DecryptionFailed);
    }
    let (nonce, ciphertext) = encrypted.split_at(12);
    let cipher = Aes256Gcm::new(GenericArray::from_slice(key));
    let decrypted = cipher.decrypt(GenericArray::from_slice(nonce), ciphertext)
        .map_err(|_| IdentityError::DecryptionFailed)?;
    Ok(decrypted)
}