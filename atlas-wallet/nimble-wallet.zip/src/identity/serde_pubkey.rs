use ed25519_dalek::PublicKey;
use serde::{Deserialize, Serializer, Deserializer};
use serde::de::Error;

pub fn serialize<S>(pk: &PublicKey, serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    serializer.serialize_bytes(pk.as_bytes())
}

pub fn deserialize<'de, D>(deserializer: D) -> Result<PublicKey, D::Error>
where
    D: Deserializer<'de>,
{
    let bytes: &[u8] = Deserialize::deserialize(deserializer)?;
    PublicKey::from_bytes(bytes).map_err(D::Error::custom)
}

#[cfg(test)]
mod tests {
    use ed25519_dalek::{PublicKey, SecretKey};
    use serde::{Serialize, Deserialize};

    #[derive(Serialize, Deserialize)]
    struct Dummy {
        #[serde(with = "super")]
        pub_key: PublicKey,
    }

    fn fixed_keypair() -> (SecretKey, PublicKey) {
        let sk = SecretKey::from_bytes(&[42u8; 32]).unwrap();
        let pk = PublicKey::from(&sk);
        (sk, pk)
    }

    #[test]
    fn test_serialize_deserialize_public_key() {
        let (_sk, pk) = fixed_keypair();

        let original = Dummy { pub_key: pk };

        let serialized = bincode::serialize(&original).expect("Serialization failed");
        let deserialized: Dummy = bincode::deserialize(&serialized).expect("Deserialization failed");

        assert_eq!(original.pub_key, deserialized.pub_key, "Original and deserialized public keys must match");
    }

    #[test]
    fn test_invalid_bytes_fail_deserialization() {
        let bad_bytes = vec![1, 2, 3, 4, 5];
        let result = PublicKey::from_bytes(&bad_bytes);
        assert!(result.is_err(), "Deserialization must fail for invalid bytes");
    }

    #[test]
    fn test_serialized_length_is_correct() {
        let (_sk, pk) = fixed_keypair();

        let serialized = bincode::serialize(&Dummy { pub_key: pk }).expect("Serialization failed");

        assert!(serialized.len() >= 32, "Serialized size should include at least 32 bytes plus overhead");
    }

    #[test]
    fn test_deserialization_from_invalid_data() {
        let bad_data = bincode::serialize(&vec![1, 2, 3, 4]).unwrap();
        let result: Result<Dummy, _> = bincode::deserialize(&bad_data);
        assert!(result.is_err(), "Should fail to deserialize invalid public key bytes");
    }
}
