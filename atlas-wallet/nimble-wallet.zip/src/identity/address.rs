use ed25519_dalek::PublicKey;
use bech32::{convert_bits, decode, encode, u5, FromBase32, Variant};
use serde::{Serialize, Deserialize};

use crate::identity::errors::IdentityError;

use super::errors::AddressError;

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct Address(String);

impl TryFrom<String> for Address {
    type Error = IdentityError;

    fn try_from(s: String) -> Result<Self, Self::Error> {
        if Address::is_valid(&s) {
            Ok(Address(s))
        } else {
            Err(IdentityError::InvalidPublicKey(format!("Invalid address: {}", s)))
        }
    }
}

impl TryFrom<&str> for Address {
    type Error = IdentityError;

    fn try_from(s: &str) -> Result<Self, Self::Error> {
        if Address::is_valid(s) {
            Ok(Address(s.to_string()))
        } else {
            Err(IdentityError::InvalidPublicKey(format!("Invalid address: {}", s)))
        }
    }
}

impl std::ops::Deref for Address {
    type Target = str;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

impl std::fmt::Display for Address {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl Address {
    /// Retorna se o endereço fornecido é válido.
    pub fn is_valid(address: &str) -> bool {
        Self::public_key_from_str(address).is_ok()
    }

    /// Extrai a chave pública de um endereço válido.
    pub fn public_key_from_str(address: &str) -> Result<PublicKey, IdentityError> {
        let (hrp, data, variant) = decode(address)
            .map_err(|e| IdentityError::InvalidPublicKey(e.to_string()))?;

        if hrp != "nimble" || variant != Variant::Bech32m {
            return Err(IdentityError::InvalidPublicKey(format!("Invalid address: {}", address)));
        }

        let bytes = Vec::<u8>::from_base32(&data)
            .map_err(|e| IdentityError::InvalidPublicKey(e.to_string()))?;

        if bytes.len() != 32 {
            return Err(IdentityError::InvalidPublicKeyLength(bytes.len()));
        }

        PublicKey::from_bytes(&bytes)
            .map_err(|e| IdentityError::InvalidPublicKey(e.to_string()))
    }

    /// Converts a `PublicKey` into a bech32m-encoded address with the "nimble" prefix.
    ///
    /// The conversion involves:
    /// - Converting the 32-byte public key into 5-bit chunks (base32 compatible).
    /// - Encoding the result with the bech32m variant.
    ///
    /// # Panics
    ///
    /// This function will panic if the conversion to 5-bit or the final encoding fails.
    ///
    /// # Example
    ///
    /// ```rust
    /// let address = address_from_pk(&public_key);
    /// assert!(address.starts_with("nimble1"));
    /// ```
    pub fn address_from_pk(public_key: &PublicKey) -> Result<String, AddressError> {
        let bytes = public_key.to_bytes();

        let five_bit: Vec<u5> = convert_bits(&bytes, 8, 5, true)
            .map_err(AddressError::BitConversionFailed)?
            .into_iter()
            .map(|b| u5::try_from_u8(b).unwrap()) // `unwrap()` aqui ainda é seguro porque `convert_bits` garante que o valor é válido
            .collect();

        encode("nimble", five_bit, Variant::Bech32m)
            .map_err(|_| AddressError::EncodingFailed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::identity::errors::IdentityError;
    use crate::identity::identity::{generate, seed};

    /// Asserts that an address generated from a public key
    /// can be parsed back to the same public key.
    #[test]
    fn test_address_from_public_key_and_back() -> Result<(), IdentityError> {
        // Usa seu próprio sistema de seed para gerar uma identidade
        let seed = seed();
        let password = "123456".to_string();
        let identity_bundle = generate(&seed, password)?;
 
        // Pegamos a public key de um profile (exemplo: exposed)
        let public_key = identity_bundle.pub_exposed;

        // Gera o endereço
        let address_str = Address::address_from_pk(&public_key)
            .map_err(|_| IdentityError::InvalidPublicKey("Failed to generate address".to_string()))?;

        // Extrai a public key de volta a partir do address
        let extracted_pk = Address::public_key_from_str(&address_str)?;

        assert_eq!(public_key, extracted_pk);

        Ok(())
    }

    /// Verifies that an invalid address string is rejected.
    #[test]
    fn test_invalid_address_is_rejected() {
        let invalid_address = "nimble1invalidaddress";

        assert!(!Address::is_valid(invalid_address));
        assert!(Address::public_key_from_str(invalid_address).is_err());
    }

    /// Verifies that a random string that is not bech32 fails.
    #[test]
    fn test_completely_invalid_format_fails() {
        let random_string = "not_even_bech32_encoded";
        assert!(Address::try_from(random_string).is_err());
        assert!(Address::public_key_from_str(random_string).is_err());
    }
}
