
use ed25519_dalek::{Keypair, PublicKey, SecretKey, Signature, Signer, Verifier};
use serde::{Serialize, Deserialize};

use crate::{
    errors::NimbleError, 
    transactions::{
        errors::TransactionError, 
        payload::TransferPayload, 
        request::TransferRequest
    }
};
use super::{
    errors::IdentityError, 
    serde_pubkey,
    secret::{encrypt_secret_key, decrypt_secret_key}
};

use nimble_sdk::{address::Address, utils::security::generate_salt};


/// Represents a user profile in the Nimble system.
///
/// Each profile is associated with a unique public key and a derived bech32m address.
/// It can be either public or private and holds a set of permissions.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Profile {
    /// Human-readable label or identifier for this profile (e.g. "hidden", "exposed", "alice-dev").
    pub id: String,

    /// The public key associated with this profile.
    #[serde(with = "serde_pubkey")]
    pub public_key: PublicKey, // TODO: make private

    /// The encrypted secret key associated with this profile.
    encrypted_sk: Option<String>,

    /// The bech32m address derived from the public key.
    pub address: Address,

    /// Whether the profile is publicly visible or not.
    pub is_public: bool,

    /// A list of permissions granted to this profile (e.g. ["transfer", "mint"]).
    pub permissions: Vec<String>,
    
    /// A list of transactions of this profile
    pub transactions: Vec<String>,

    pub salt: [u8; 16],
}

impl Profile {
    /// Creates a new `Profile` from a given secret seed.
    ///
    /// # Arguments
    ///
    /// * `seed` - A 32-byte seed to generate the secret key.
    /// * `label` - A human-readable identifier for the profile.
    /// * `is_public` - Indicates if the profile is publicly visible.
    /// * `permissions` - A list of permission strings assigned to the profile.
    ///
    /// # Panics
    ///
    /// This function will panic if the seed is not a valid Ed25519 secret key.
    pub fn new_from_seed(
        seed: &[u8],
        password: String, 
        label: &str, 
        is_public: bool, 
        permissions: Vec<String>
    ) -> Result<Self, IdentityError> {
        // TODO: Return only encrypted secret key
        let secret = SecretKey::from_bytes(seed)
            .map_err(|e|IdentityError::ProfileCreationFailed(e))?;
        let public = PublicKey::from(&secret);
        let address = Address::address_from_pk(&public)?;
        let salt = generate_salt();
        let encrypted_sk = encrypt_secret_key( &secret, password, salt)?;
        Ok(Profile {
            id: label.to_string(),
            public_key: public,
            encrypted_sk: Some(encrypted_sk.to_string()),
            address: Address::try_from(address)?,
            is_public,
            permissions,
            salt,
            transactions: vec![],
        })
    }

    pub fn add_payload(&mut self, to: &Address, amount: u64) {
        let payload = TransferPayload::new(&self.address, to, amount);
        self.transactions.push(payload.to_string());
    }

    pub fn build_signed_request<'a>(
        &'a self,
        to: &'a Address,
        amount: u64,
        password: String,
        memo: Option<&str>,
    ) -> Result<TransferRequest<'a>, NimbleError> {
        let payload = TransferPayload::new(&self.address, to, amount);
        let sig2 = self.sign(password, payload.to_string().as_bytes())?;

        let request = TransferRequest::build_signed_request(
            &self.address,
            &to,
            amount,
            sig2.to_vec(),
            memo.map(|m| m.to_string()),
        )?;

        Ok(request)
    }

    pub fn sign(&self, encryption_key: String, message: &[u8]) -> Result<[u8; 64], IdentityError> {
        let encrypted = self.encrypted_sk.clone().ok_or(IdentityError::InvalidPrivateKey("missing key".into()))?;
        let secret = decrypt_secret_key(&encrypted, encryption_key, self.salt)?;
        let public = PublicKey::from(&secret);
        let keypair = Keypair { secret, public };
        Ok(keypair.sign(message).to_bytes())
    }

    pub fn validate_transfer(&self, request: TransferRequest) -> Result<(), NimbleError> {
        let payload = request.to_payload();

        if !payload.is_valid() {
            return Err(TransactionError::InvalidPayload("Invalid payload".into()).into());
        }

        let signature = Signature::from_bytes(&request.sig2)
            .map_err(|_| TransactionError::InvalidPasswordSignature("Invalid signature format".into()))?;

        self.public_key
            .verify(payload.to_string().as_bytes(), &signature)
            .map_err(|_| TransactionError::InvalidPasswordSignature("Signature verification failed".into()))?;

        Ok(())
    }

    pub fn validate_transferbkp(&self, password: String, request: TransferRequest) -> Result<(), NimbleError> {
        let payload = request.to_payload();
        let expected_sig2 = self.sign(password, payload.to_string().as_bytes())?;

        if !payload.is_valid() {
            println!("Invalid Payload");
            return Err(TransactionError::InvalidPayload("Invalid payload".into()).into());  
        }

        if request.sig2 != expected_sig2 {
            println!("Invalid Signature");
            return Err(TransactionError::InvalidPasswordSignature("Invalid signature".into()).into());
        }

        Ok(())
    }


    pub fn validate_permissions(&self, permission: String) -> Result<(), IdentityError> {
        if !self.permissions.contains(&permission) {
            return Err(IdentityError::InvalidPermission(
                format!("Profile '{}' does not have permission '{}'", self.id, permission)
            ));
        }
        Ok(())
    }

    pub fn try_validate_permissions(&self, permission: &str) -> bool {
        self.permissions.contains(&permission.to_string())
    }

    pub fn zeroize(&mut self) {
        use zeroize::Zeroize;
        self.encrypted_sk.zeroize();
        self.salt.zeroize();
    }

     pub fn is_cleared(&self) -> bool {
        match &self.encrypted_sk {
            Some(sk) => sk.is_empty(),
            None => true,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn create_test_profile(password: &str, permissions: Vec<String>) -> Profile {
        let seed = [42u8; 32];
        Profile::new_from_seed(&seed, password.to_string(), "exposed", true, permissions).unwrap()
    }

    #[test]
    fn test_profile_creation() {
        let profile = create_test_profile("password", vec!["transfer".into()]);
        assert_eq!(profile.id, "exposed");
        assert_eq!(profile.is_public, true);
        assert_eq!(profile.permissions.len(), 1);
    }

    #[test]
    fn test_sign_message() {
        let profile = create_test_profile("secret", vec![]);
        let message = b"hello blockchain";
        let signature = profile.sign("secret".to_string(), message).unwrap();
        assert_eq!(signature.len(), 64);
    }

    #[test]
    fn test_invalid_password_signature_fails() {
        let profile = create_test_profile("right", vec![]);
        let message = b"wrong attempt";
        let result = profile.sign("wrong".to_string(), message);
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_transfer_ok() {
        let profile = create_test_profile("password", vec!["transfer".into()]);
        let to = profile.address.clone();
        let request = profile.build_signed_request(&to, 10, "password".to_string(), None).unwrap();
        let result = profile.validate_transfer(request);
        assert!(result.is_ok());
    }

    #[test]
    fn test_validate_permissions_success() {
        let profile = create_test_profile("pwd", vec!["mint".into()]);
        assert!(profile.validate_permissions("mint".to_string()).is_ok());
    }

    #[test]
    fn test_validate_permissions_failure() {
        let profile = create_test_profile("pwd", vec!["stake".into()]);
        let result = profile.validate_permissions("mint".to_string());
        assert!(result.is_err());
    }

    #[test]
    fn test_try_validate_permissions() {
        let profile = create_test_profile("pwd", vec!["read".into()]);
        assert!(profile.try_validate_permissions("read"));
        assert!(!profile.try_validate_permissions("write"));
    }
}


