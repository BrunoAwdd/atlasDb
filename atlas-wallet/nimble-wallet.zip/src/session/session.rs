use crate::errors::NimbleError;
use crate::identity::errors::IdentityError;
use crate::identity::identity::{Identity, IdentityBundle};
use crate::profile::profile_type::{Profile, ProfileType,};
use nimble_sdk::address::profile_address::ProfileAddress;
use nimble_sdk::transactions::{payload::TransferPayload, TransferRequest};

pub struct Session {
    pub identity: Identity,
    pub profile: Profile,
}

impl Session {
    /// Cria uma nova sessão com um Profile e Identity carregados
    pub fn new(identity: Identity) -> Result<Self, NimbleError> {
        let profile = Profile::Exposed(identity.clone().exposed);
        Ok(Self { identity, profile })
    }

    pub fn from_bundle(bundle: IdentityBundle) -> Result<Self, NimbleError> {
        let session = Self::new(bundle.identity)?;
        Ok(session)
    }

pub fn switch_profile(&mut self, profile_id: &str) -> Result<&dyn ProfileType, IdentityError> {
    match profile_id {
        "hidden" => {
            self.profile = Profile::Hidden(self.identity.hidden.clone());
        }
        "exposed" => {
            self.profile = Profile::Exposed(self.identity.exposed.clone());
        }
        _ => {
            return Err(IdentityError::ProfileNotFound(profile_id.to_string()));
        }
    }

    Ok(match &self.profile {
        Profile::Hidden(p) => p,
        Profile::Exposed(p) => p,
    })
}
    /// Exemplo de função para assinar uma mensagem
    pub fn sign_message(&self, password: String, message: &[u8]) -> Result<Vec<u8>, NimbleError> {
        println!("🔐 Signing message {:?}", self.profile.id());
        let sig = self.profile.sign(password, message)?;
        Ok(sig.to_vec())
    }

    pub fn create_signed_transfer<'a>(
        &'a self,
        to_address: &'a str,
        amount: u64,
        password: String,
        memo: Option<String>,
    ) -> Result<TransferRequest<'a>, NimbleError> {
        let payload = TransferPayload::new(&self.profile.address().as_str(), to_address, amount);

        println!("🔐 Payload: {:?} {:?}", payload, password);

        let signature = self.sign_message(password, payload.to_string().as_bytes())?;

        println!("🔐 Signature: {:?}", signature);

        let request: TransferRequest<'a> =TransferRequest::build_signed_request(
            &self.profile.address().as_str(),
            to_address,
            amount,
            signature,
            memo,
        )?;

        Ok(request)
    }

    /// Limpa os dados da sessão (para segurança)
    pub fn clear(&mut self) {
        self.profile.zeroize();
        // Adicione zeroization no Identity também, se quiser
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{identity::identity::generate, profile::profile_type::ProfileType};

    fn create_test_session() -> Session {
        let seed = [42u8; 32];
        let password = "test-password".to_string();
        let bundle = generate(&seed, password.clone()).unwrap();

        let session = Session::new(bundle.identity).unwrap();
        session
    }

    #[test]
    fn test_session_creation() {
        let session = create_test_session();
        assert_eq!(session.profile.id(), "exposed");
        assert!(session.identity.exposed.is_public());
        assert!(!session.identity.hidden.is_public());
    }
    
    #[test]
    fn test_switch_profile() {
        let mut session = create_test_session();
        session.switch_profile("hidden").unwrap();
        assert_eq!(session.profile.id(), "hidden");
        assert_ne!(session.profile.id(), "exposed");
    }

    #[test]
    fn test_session_sign_message() {
        let session = create_test_session();
        let message = b"hello nimble";

        let signature = session.sign_message("test-password".to_string(), message)
            .expect("Signing should succeed");

        assert_eq!(signature.len(), 64); // ed25519 signatures são sempre 64 bytes
    }

    #[test]
    fn test_session_clear() {
        let mut session = create_test_session();

        session.clear();

        // Verifica que campos sensíveis foram zerados
        assert!(session.profile.is_cleared(), "Profile should be cleared");
    }
}
